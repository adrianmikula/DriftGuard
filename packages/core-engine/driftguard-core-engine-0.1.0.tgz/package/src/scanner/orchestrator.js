"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScannerOrchestrator = void 0;
class ScannerOrchestrator {
    graph;
    ruleEngine;
    analyzers = new Map();
    constructor(graph, ruleEngine) {
        this.graph = graph;
        this.ruleEngine = ruleEngine;
    }
    registerAnalyzer(analyzer) {
        this.analyzers.set(analyzer.language, analyzer);
    }
    unregisterAnalyzer(language) {
        this.analyzers.delete(language);
    }
    async scan(context) {
        const startTime = Date.now();
        const analyzer = this.analyzers.get(context.language);
        if (!analyzer) {
            throw new Error(`No analyzer found for language: ${context.language}`);
        }
        try {
            // Run language-specific analysis
            await analyzer.analyze(context, this.graph);
            // Execute all rules
            const violations = await this.ruleEngine.executeAllRules(context);
            const duration = Date.now() - startTime;
            return {
                success: true,
                violations,
                metrics: {
                    filesScanned: context.files.length,
                    nodesCreated: 0, // TODO: Track from graph operations
                    edgesCreated: 0, // TODO: Track from graph operations
                    duration,
                },
            };
        }
        catch (error) {
            return {
                success: false,
                violations: [],
                metrics: {
                    filesScanned: 0,
                    nodesCreated: 0,
                    edgesCreated: 0,
                    duration: Date.now() - startTime,
                },
            };
        }
    }
}
exports.ScannerOrchestrator = ScannerOrchestrator;
