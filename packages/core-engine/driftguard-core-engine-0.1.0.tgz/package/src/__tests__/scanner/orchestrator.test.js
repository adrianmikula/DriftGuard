"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const orchestrator_1 = require("../../scanner/orchestrator");
const engine_1 = require("../../rules/engine");
(0, vitest_1.describe)('ScannerOrchestrator', () => {
    let orchestrator;
    let mockRuleEngine;
    let mockGraph;
    const createMockLanguageAnalyzer = (name, shouldSucceed = true) => ({
        language: name,
        analyze: async (_context, _graph) => {
            if (!shouldSucceed) {
                throw new Error('Analyzer failed');
            }
        },
    });
    const createScanContext = (overrides) => ({
        workspacePath: '/test/workspace',
        language: 'typescript',
        files: ['/test/workspace/file1.ts', '/test/workspace/file2.ts'],
        ...overrides,
    });
    (0, vitest_1.beforeEach)(() => {
        mockRuleEngine = new engine_1.RuleEngine();
        mockGraph = {};
        orchestrator = new orchestrator_1.ScannerOrchestrator(mockGraph, mockRuleEngine);
    });
    (0, vitest_1.describe)('registerAnalyzer', () => {
        (0, vitest_1.it)('should register a language analyzer', () => {
            const analyzer = createMockLanguageAnalyzer('typescript');
            orchestrator.registerAnalyzer(analyzer);
            // Access internal state via public methods - orchestrator doesn't expose getAnalyzer
            // So we test through scan behavior
            (0, vitest_1.expect)(orchestrator).toBeDefined();
        });
        (0, vitest_1.it)('should overwrite existing analyzer for same language', () => {
            const analyzer1 = createMockLanguageAnalyzer('typescript');
            const analyzer2 = createMockLanguageAnalyzer('typescript', false);
            orchestrator.registerAnalyzer(analyzer1);
            orchestrator.registerAnalyzer(analyzer2);
            // New analyzer replaces old one
            (0, vitest_1.expect)(orchestrator).toBeDefined();
        });
    });
    (0, vitest_1.describe)('unregisterAnalyzer', () => {
        (0, vitest_1.it)('should remove a language analyzer', () => {
            const analyzer = createMockLanguageAnalyzer('python');
            orchestrator.registerAnalyzer(analyzer);
            orchestrator.unregisterAnalyzer('python');
            // Verify by attempting to scan - should throw "no analyzer found"
            return (0, vitest_1.expect)(orchestrator.scan(createScanContext({ language: 'python' })))
                .rejects.toThrow('No analyzer found for language: python');
        });
        (0, vitest_1.it)('should not throw if analyzer does not exist', () => {
            (0, vitest_1.expect)(() => orchestrator.unregisterAnalyzer('nonexistent')).not.toThrow();
        });
    });
    (0, vitest_1.describe)('scan', () => {
        (0, vitest_1.beforeEach)(async () => {
            // Register a default rule that always passes to simplify tests
            const passingRule = {
                id: 'passing-rule',
                name: 'Passing',
                description: 'Always passes',
                check: async () => ({ passed: true, violations: [] }),
            };
            mockRuleEngine.registerRule(passingRule);
        });
        (0, vitest_1.it)('should return success result when scan completes', async () => {
            const analyzer = createMockLanguageAnalyzer('typescript');
            orchestrator.registerAnalyzer(analyzer);
            const result = await orchestrator.scan(createScanContext());
            (0, vitest_1.expect)(result).toHaveProperty('success', true);
            (0, vitest_1.expect)(result).toHaveProperty('violations');
            (0, vitest_1.expect)(result).toHaveProperty('metrics');
            (0, vitest_1.expect)(result.metrics).toHaveProperty('filesScanned', 2);
        });
        (0, vitest_1.it)('should return metrics with duration and file count', async () => {
            const analyzer = createMockLanguageAnalyzer('typescript');
            orchestrator.registerAnalyzer(analyzer);
            const result = await orchestrator.scan(createScanContext());
            (0, vitest_1.expect)(result.metrics.filesScanned).toBe(2);
            (0, vitest_1.expect)(result.metrics.duration).toBeGreaterThanOrEqual(0);
        });
        (0, vitest_1.it)('should execute rules and include violations in result', async () => {
            // Add a rule that fails
            const failingRule = {
                id: 'failing-rule',
                name: 'Failing',
                description: 'Always fails',
                check: async () => ({
                    passed: false,
                    violations: [{
                            ruleId: 'failing-rule',
                            severity: 'error',
                            message: 'Test violation',
                            location: { file: 'test.ts' },
                        }],
                }),
            };
            mockRuleEngine.registerRule(failingRule);
            const analyzer = createMockLanguageAnalyzer('typescript');
            orchestrator.registerAnalyzer(analyzer);
            const result = await orchestrator.scan(createScanContext());
            (0, vitest_1.expect)(result.violations).toHaveLength(1);
            (0, vitest_1.expect)(result.violations[0].ruleId).toBe('failing-rule');
        });
        (0, vitest_1.it)('should handle analyzer not found error', async () => {
            const context = createScanContext({ language: 'unsupported' });
            const result = await orchestrator.scan(context);
            (0, vitest_1.expect)(result.success).toBe(false);
            (0, vitest_1.expect)(result.violations).toEqual([]);
            (0, vitest_1.expect)(result.metrics.filesScanned).toBe(0);
        });
        (0, vitest_1.it)('should handle analyzer throwing an exception', async () => {
            const failingAnalyzer = createMockLanguageAnalyzer('typescript', false);
            orchestrator.registerAnalyzer(failingAnalyzer);
            const result = await orchestrator.scan(createScanContext());
            (0, vitest_1.expect)(result.success).toBe(false);
            (0, vitest_1.expect)(result.violations).toEqual([]);
        });
        (0, vitest_1.it)('should execute all registered rules', async () => {
            orchestrator.registerAnalyzer(createMockLanguageAnalyzer('typescript'));
            const rule1 = { id: 'r1', name: 'R1', description: '', check: async () => ({ passed: true, violations: [] }) };
            const rule2 = { id: 'r2', name: 'R2', description: '', check: async () => ({ passed: true, violations: [] }) };
            mockRuleEngine.registerRule(rule1);
            mockRuleEngine.registerRule(rule2);
            const executeAllSpy = vitest_1.vi.spyOn(mockRuleEngine, 'executeAllRules');
            await orchestrator.scan(createScanContext());
            (0, vitest_1.expect)(executeAllSpy).toHaveBeenCalledOnce();
        });
    });
});
