"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
// Mock neo4j-driver before importing GraphClient
vitest_1.vi.mock('neo4j-driver', async () => await Promise.resolve().then(() => __importStar(require('../../__mocks__/neo4j-driver'))));
const client_1 = require("../../graph/client");
const neo4j_driver_1 = require("../../__mocks__/neo4j-driver");
const utils_1 = require("../utils");
(0, vitest_1.describe)('GraphClient', () => {
    let client;
    let mockDriver;
    (0, vitest_1.beforeEach)(() => {
        (0, neo4j_driver_1.resetMocks)();
        mockDriver = (0, neo4j_driver_1.getMockDriver)();
        const config = (0, utils_1.createGraphClientConfig)();
        client = new client_1.GraphClient(config);
    });
    (0, vitest_1.describe)('connect', () => {
        (0, vitest_1.it)('should successfully connect to the database', async () => {
            const verifySpy = vitest_1.vi.spyOn(mockDriver, 'verifyConnectivity');
            await client.connect();
            (0, vitest_1.expect)(verifySpy).toHaveBeenCalledOnce();
        });
    });
    (0, vitest_1.describe)('executeQuery', () => {
        (0, vitest_1.it)('should execute a query and return records', async () => {
            const result = await client.executeQuery('MATCH (n) RETURN n.name');
            (0, vitest_1.expect)(result).toBeDefined();
            (0, vitest_1.expect)(Array.isArray(result)).toBe(true);
            (0, vitest_1.expect)(result.length).toBeGreaterThan(0);
            (0, vitest_1.expect)(result[0]).toHaveProperty('get');
        });
        (0, vitest_1.it)('should execute query with parameters', async () => {
            const sessionSpy = vitest_1.vi.spyOn(mockDriver, 'session');
            await client.executeQuery('MATCH (n) WHERE n.name = $name RETURN n', { name: 'test' });
            (0, vitest_1.expect)(sessionSpy).toHaveBeenCalledTimes(1);
        });
        (0, vitest_1.it)('should close session after query execution', async () => {
            const mockSession = mockDriver.session();
            const closeSpy = vitest_1.vi.spyOn(mockSession, 'close');
            await client.executeQuery('MATCH (n) RETURN n');
            (0, vitest_1.expect)(closeSpy).toHaveBeenCalledOnce();
        });
    });
    (0, vitest_1.describe)('executeWrite', () => {
        (0, vitest_1.it)('should execute a write query without returning data', async () => {
            const session = mockDriver.session();
            const runSpy = vitest_1.vi.spyOn(session, 'run');
            await client.executeWrite('CREATE (n:Node {name: $name})', { name: 'test' });
            (0, vitest_1.expect)(runSpy).toHaveBeenCalledOnce();
            (0, vitest_1.expect)(session.close).toHaveBeenCalledOnce();
        });
    });
    (0, vitest_1.describe)('getDriver', () => {
        (0, vitest_1.it)('should return the underlying driver instance', () => {
            const driver = client.getDriver();
            (0, vitest_1.expect)(driver).toBeDefined();
        });
    });
    (0, vitest_1.describe)('close', () => {
        (0, vitest_1.it)('should close the driver connection', async () => {
            const closeSpy = vitest_1.vi.spyOn(mockDriver, 'close');
            await client.close();
            (0, vitest_1.expect)(closeSpy).toHaveBeenCalledOnce();
        });
    });
});
