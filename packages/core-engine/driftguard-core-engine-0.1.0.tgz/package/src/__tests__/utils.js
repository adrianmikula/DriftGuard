"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleViolationSchema = void 0;
exports.createGraphClientConfig = createGraphClientConfig;
exports.createRuleViolation = createRuleViolation;
exports.createRuleResult = createRuleResult;
exports.createMockRecord = createMockRecord;
exports.createMockResult = createMockResult;
const zod_1 = require("zod");
function createGraphClientConfig(overrides) {
    return {
        uri: 'bolt://localhost:7687',
        username: 'neo4j',
        password: 'password',
        ...overrides,
    };
}
function createRuleViolation(overrides) {
    return {
        ruleId: 'test-rule',
        severity: 'error',
        message: 'Test violation message',
        location: { file: 'test.ts' },
        ...overrides,
    };
}
function createRuleResult(overrides) {
    return {
        passed: true,
        violations: [],
        ...overrides,
    };
}
function createMockRecord(data) {
    return {
        keys: Object.keys(data),
        get: (key) => data[key],
        toJSON: () => data,
    };
}
function createMockResult(records) {
    return {
        records: records.map(createMockRecord),
        sum: () => records.length,
        consume: () => ({ stats: { counters: {} } }),
    };
}
// RuleViolation schema for type inference
exports.RuleViolationSchema = zod_1.z.object({
    ruleId: zod_1.z.string(),
    severity: zod_1.z.enum(['error', 'warning', 'info']),
    message: zod_1.z.string(),
    location: zod_1.z.object({
        file: zod_1.z.string(),
        line: zod_1.z.number().optional(),
        column: zod_1.z.number().optional(),
    }),
    metadata: zod_1.z.record(zod_1.z.any()).optional(),
});
