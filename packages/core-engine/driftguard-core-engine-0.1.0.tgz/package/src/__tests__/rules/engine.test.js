"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const engine_1 = require("../../rules/engine");
(0, vitest_1.describe)('RuleEngine', () => {
    let engine;
    const createMockRule = (id, passed, violations = []) => ({
        id,
        name: `Mock Rule ${id}`,
        description: 'A mock rule for testing',
        check: async (_context) => ({
            passed,
            violations,
        }),
    });
    (0, vitest_1.beforeEach)(() => {
        engine = new engine_1.RuleEngine();
    });
    (0, vitest_1.describe)('registerRule', () => {
        (0, vitest_1.it)('should register a rule', () => {
            const rule = createMockRule('rule1', true);
            engine.registerRule(rule);
            (0, vitest_1.expect)(engine.getRule('rule1')).toBe(rule);
        });
        (0, vitest_1.it)('should overwrite existing rule with same id', () => {
            const rule1 = createMockRule('rule1', true);
            const rule2 = createMockRule('rule1', false, [{ ruleId: 'rule1', severity: 'error', message: 'fail', location: { file: 'test' } }]);
            engine.registerRule(rule1);
            engine.registerRule(rule2);
            (0, vitest_1.expect)(engine.getRule('rule1')).toBe(rule2);
        });
    });
    (0, vitest_1.describe)('unregisterRule', () => {
        (0, vitest_1.it)('should remove a registered rule', () => {
            const rule = createMockRule('rule1', true);
            engine.registerRule(rule);
            engine.unregisterRule('rule1');
            (0, vitest_1.expect)(engine.getRule('rule1')).toBeUndefined();
        });
        (0, vitest_1.it)('should do nothing if rule does not exist', () => {
            (0, vitest_1.expect)(() => engine.unregisterRule('nonexistent')).not.toThrow();
        });
    });
    (0, vitest_1.describe)('getAllRules', () => {
        (0, vitest_1.it)('should return all registered rules', () => {
            engine.registerRule(createMockRule('rule1', true));
            engine.registerRule(createMockRule('rule2', true));
            const rules = engine.getAllRules();
            (0, vitest_1.expect)(rules).toHaveLength(2);
        });
        (0, vitest_1.it)('should return empty array when no rules registered', () => {
            (0, vitest_1.expect)(engine.getAllRules()).toEqual([]);
        });
    });
    (0, vitest_1.describe)('executeRule', () => {
        (0, vitest_1.it)('should execute a registered rule and return its result', async () => {
            const rule = createMockRule('rule1', true);
            engine.registerRule(rule);
            const result = await engine.executeRule('rule1', {});
            (0, vitest_1.expect)(result.passed).toBe(true);
        });
        (0, vitest_1.it)('should throw an error if rule is not found', async () => {
            await (0, vitest_1.expect)(engine.executeRule('nonexistent', {})).rejects.toThrow('Rule not found: nonexistent');
        });
    });
    (0, vitest_1.describe)('executeAllRules', () => {
        (0, vitest_1.it)('should execute all registered rules', async () => {
            engine.registerRule(createMockRule('rule1', true));
            engine.registerRule(createMockRule('rule2', false, [{
                    ruleId: 'rule2',
                    severity: 'error',
                    message: 'violation',
                    location: { file: 'test.ts' },
                }]));
            const results = await engine.executeAllRules({});
            (0, vitest_1.expect)(results).toHaveLength(2);
            (0, vitest_1.expect)(results[0].passed).toBe(true);
            (0, vitest_1.expect)(results[1].passed).toBe(false);
            (0, vitest_1.expect)(results[1].violations).toHaveLength(1);
        });
        (0, vitest_1.it)('should return empty array when no rules registered', async () => {
            const results = await engine.executeAllRules({});
            (0, vitest_1.expect)(results).toEqual([]);
        });
    });
});
