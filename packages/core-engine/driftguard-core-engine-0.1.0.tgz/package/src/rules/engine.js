"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleConfigSchema = exports.RuleEngine = void 0;
const zod_1 = require("zod");
class RuleEngine {
    rules = new Map();
    registerRule(rule) {
        this.rules.set(rule.id, rule);
    }
    unregisterRule(ruleId) {
        this.rules.delete(ruleId);
    }
    getRule(ruleId) {
        return this.rules.get(ruleId);
    }
    getAllRules() {
        return Array.from(this.rules.values());
    }
    async executeRule(ruleId, context) {
        const rule = this.rules.get(ruleId);
        if (!rule) {
            throw new Error(`Rule not found: ${ruleId}`);
        }
        return await rule.check(context);
    }
    async executeAllRules(context) {
        const results = [];
        for (const rule of this.rules.values()) {
            const result = await rule.check(context);
            results.push(result);
        }
        return results;
    }
}
exports.RuleEngine = RuleEngine;
// Configuration schema for rules
exports.RuleConfigSchema = zod_1.z.object({
    enabled: zod_1.z.boolean(),
    severity: zod_1.z.enum(['error', 'warning', 'info']),
    options: zod_1.z.record(zod_1.z.any()).optional(),
});
