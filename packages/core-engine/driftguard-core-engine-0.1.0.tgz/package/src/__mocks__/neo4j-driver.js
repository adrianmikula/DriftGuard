"use strict";
// Mock for neo4j-driver that supports both default and named imports
// Used by GraphClient: import neo4j, { Driver, Session, Record } from 'neo4j-driver';
Object.defineProperty(exports, "__esModule", { value: true });
exports.auth = exports.driver = void 0;
exports.setMockDriver = setMockDriver;
exports.resetMocks = resetMocks;
const mockDriverInstance = {
    session: vi.fn(() => ({
        run: vi.fn().mockResolvedValue({
            records: [
                { keys: () => ['name'], get: (k) => ({ name: 'Test Node' }), toJSON: () => ({ name: 'Test Node' }) },
                { keys: () => ['count'], get: (k) => ({ count: 5 }), toJSON: () => ({ count: 5 }) }
            ],
            sum: () => 2,
            consume: () => ({ stats: { counters: {} } }),
        }),
        close: vi.fn().mockResolvedValue(undefined),
    })),
    close: vi.fn().mockResolvedValue(undefined),
    verifyConnectivity: vi.fn().mockResolvedValue(undefined),
};
exports.driver = vi.fn().mockReturnValue(mockDriverInstance);
exports.auth = {
    basic: vi.fn().mockReturnValue({}),
};
exports.default = { driver: exports.driver, auth: exports.auth };
function setMockDriver(customDriver) {
    Object.assign(mockDriverInstance, customDriver);
}
function resetMocks() {
    vi.clearAllMocks();
    exports.driver.mockReturnValue(mockDriverInstance);
    exports.auth.basic.mockReturnValue({});
}
